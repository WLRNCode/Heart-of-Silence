<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.1" name="tiles" tilewidth="50" tileheight="50" tilecount="3" columns="3">
 <image source="tiles.png" width="150" height="50"/>
</tileset>
